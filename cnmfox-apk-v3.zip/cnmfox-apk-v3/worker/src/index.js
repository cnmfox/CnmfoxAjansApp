// CNMFOX API — Cloudflare Worker (v3 : détection Facebook + poll Apify)
// Acteur Apify vérifié nov. 2026 : compass/crawler-google-places (596k users, 4.70/5).
// L'ancien slug apify/google-maps-scraper est retiré (404) — ne pas l'utiliser.
const APIFY_ACTOR = 'compass/crawler-google-places';
const SCRAPE_TTL = 60 * 60 * 24;
const AI_TTL = 60 * 60 * 24 * 7;
const RATE_LIMIT_MAX = 60;
const RATE_LIMIT_WINDOW = 3600;

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const origin = request.headers.get('Origin') || '*';
    if (request.method === 'OPTIONS') return cors(new Response(null, { status: 204 }), origin, env);
    try {
      if (url.pathname === '/api/health') return cors(json({ ok: true, ts: Date.now(), apify: !!env.APIFY_TOKEN, firecrawl: !!env.FIRECRAWL_KEY, deepseek: !!env.DEEPSEEK_KEY }), origin, env);
      const token = request.headers.get('X-CNMFOX-Token');
      if (!env.CNMFOX_TOKEN || token !== env.CNMFOX_TOKEN) return cors(json({ error: 'unauthorized' }, 401), origin, env);
      const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
      const rl = await rateLimit(env, ip);
      if (!rl.ok) return cors(json({ error: 'rate_limit', resetIn: rl.resetIn }, 429), origin, env);
      if (url.pathname === '/api/search' && request.method === 'POST') return cors(json(await search(request, env)), origin, env);
      if (url.pathname === '/api/scrape' && request.method === 'POST') return cors(json(await scrape(request, env)), origin, env);
      if (url.pathname === '/api/ai' && request.method === 'POST') return cors(json(await ai(request, env)), origin, env);
      return cors(json({ error: 'not_found' }, 404), origin, env);
    } catch (e) {
      console.error(e);
      return cors(json({ error: e.message || 'internal' }, 500), origin, env);
    }
  }
};

async function apifyRunAndWait(env, input) {
  let runRes = await fetch(`https://api.apify.com/v2/acts/${encodeURIComponent(APIFY_ACTOR)}/runs?token=${env.APIFY_TOKEN}&waitForFinish=120`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input)
  });
  if (!runRes.ok) throw new Error('apify_run ' + runRes.status);
  let run = (await runRes.json()).data;
  // Poll jusqu'à 3 fois supplémentaires si l'acteur tourne encore
  let tries = 0;
  while (run.status !== 'SUCCEEDED' && run.status !== 'FAILED' && tries < 3) {
    await new Promise(r => setTimeout(r, 30000));
    const st = await fetch(`https://api.apify.com/v2/actor-runs/${run.id}?token=${env.APIFY_TOKEN}`);
    run = (await st.json()).data;
    tries++;
  }
  if (run.status !== 'SUCCEEDED') throw new Error('apify_status ' + run.status);
  const dsRes = await fetch(`https://api.apify.com/v2/datasets/${run.defaultDatasetId}/items?token=${env.APIFY_TOKEN}&limit=10`);
  if (!dsRes.ok) throw new Error('apify_dataset ' + dsRes.status);
  return dsRes.json();
}

async function search(request, env) {
  const { mode = 'gm', q, loc } = await request.json();
  if (!q) throw new Error('missing q');
  if (mode === 'gm') {
    if (!env.APIFY_TOKEN) throw new Error('APIFY_TOKEN missing');
    const items = await apifyRunAndWait(env, { language: 'fr', locationQuery: loc || 'Haiti', maxCrawledPlacesPerSearch: 10, searchStringsArray: [q] });
    const leads = (items || []).map(x => ({ name: x.title, category: x.categoryName, phone: x.phone || x.phoneUnformatted, website: x.website, address: x.address, rating: x.totalScore, reviews: x.reviewsCount }));
    return { leads };
  }
  if (!env.FIRECRAWL_KEY) throw new Error('FIRECRAWL_KEY missing');
  const fcRes = await fetch('https://api.firecrawl.dev/v1/search', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${env.FIRECRAWL_KEY}` }, body: JSON.stringify({ query: `${q} ${loc || ''}`.trim(), limit: 8 }) });
  if (!fcRes.ok) throw new Error('firecrawl_search ' + fcRes.status);
  const fcData = await fcRes.json();
  const web = fcData.data?.web || fcData.web || [];
  // On garde Facebook (catégorie "Facebook" = lead chaud : présence en ligne mais pas de site) ; on filtre les autres réseaux/agrégateurs.
  const BLACK = /tripadvisor|yelp|wikipedia|google\.|booking\.com|mapquest|foursquare|restaurantguru|youtube|linkedin|pinterest|alamy|expedia|instagram\.|tiktok\./i;
  return {
    leads: web.filter(w => w.url && !BLACK.test(w.url)).map(w => {
      const isFb = /facebook\.com/i.test(w.url);
      return { name: (w.title || w.url || '').replace(/\s*[-|–].*$/, '').slice(0, 60), category: isFb ? 'Facebook' : 'Web', website: w.url, facebook: isFb ? w.url : null, address: '', phone: null };
    })
  };
}

async function scrape(request, env) {
  const { url } = await request.json();
  if (!url) throw new Error('missing url');
  const cacheKey = 'scrape:' + url;
  const cached = await env.CACHE?.get(cacheKey, 'json');
  if (cached) return { ...cached, cached: true };
  if (!env.FIRECRAWL_KEY) throw new Error('FIRECRAWL_KEY missing');
  const fcRes = await fetch('https://api.firecrawl.dev/v1/scrape', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${env.FIRECRAWL_KEY}` }, body: JSON.stringify({ url, formats: ['rawHtml'], timeout: 30000 }) });
  if (!fcRes.ok) return { ok: false, statusCode: fcRes.status === 500 ? 0 : fcRes.status, hasSSL: false, hasViewport: false, hasWhatsApp: false, hasFacebook: false, phone: null };
  const data = await fcRes.json();
  const p = data.data || data;
  const html = p.rawHtml || '';
  const md = p.metadata || {};
  const statusCode = md.statusCode || 200;
  const fbMatch = html.match(/facebook\.com\/([A-Za-z0-9._-]{3,})/i);
  const result = {
    ok: statusCode < 400, statusCode,
    hasSSL: /^https:/.test(md.url || url),
    hasViewport: /name=["']viewport/i.test(html),
    hasWhatsApp: /wa\.me|api\.whatsapp\.com|whatsapp\.com\/send/i.test(html),
    hasFacebook: !!fbMatch,
    facebookUrl: fbMatch ? 'https://facebook.com/' + fbMatch[1] : null,
    phone: (html + ' ' + (md.description || '')).match(/(?:\+?509[\s.-]?)?\b[2-4]\d{3}[\s.-]?\d{4}\b/)?.[0] || null,
    title: md.title || '', content: html.slice(0, 8000)
  };
  if (statusCode < 500) await env.CACHE?.put(cacheKey, JSON.stringify(result), { expirationTtl: SCRAPE_TTL });
  return result;
}

async function ai(request, env) {
  const body = await request.json();
  const { task, lead, content } = body;
  if (!task) throw new Error('missing task');
  const cacheKey = task === 'score' ? 'ai:score:' + JSON.stringify(lead).slice(0, 200) : null;
  if (cacheKey) {
    const c = await env.CACHE?.get(cacheKey, 'json');
    if (c) return { ...c, cached: true };
  }
  if (!env.DEEPSEEK_KEY) return heuristicAI(task, lead);
  const systemPrompts = {
    score: `Tu es un analyste d'agence web. Reçois un prospect (nom, catégorie, problèmes détectés sur son site). Retourne STRICTEMENT ce JSON : {"score": <1-10>, "reason": ""}. Score 9-10 = urgence. 5-8 = médiocre. 1-4 = bon site.`,
    pitch: `Tu es un commercial de CNMFOX, agence web haïtienne. Rédige un message WhatsApp court (max 120 mots) en français. Ton chaleureux, professionnel. Commence par "Bonjour [nom]". Termine par "— CNMFOX".`
  };
  const userContent = task === 'score' ? JSON.stringify({ name: lead?.name, category: lead?.category, checks: lead?.checks }) : JSON.stringify({ name: lead?.name, category: lead?.category, checks: lead?.checks, content: (content || '').slice(0, 3000) });
  const dsRes = await fetch('https://api.deepseek.com/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${env.DEEPSEEK_KEY}` }, body: JSON.stringify({ model: env.DEEPSEEK_MODEL || 'deepseek-chat', messages: [{ role: 'system', content: systemPrompts[task] || systemPrompts.score }, { role: 'user', content: userContent }], temperature: task === 'pitch' ? 0.8 : 0.2, max_tokens: task === 'pitch' ? 400 : 150, response_format: task === 'score' ? { type: 'json_object' } : undefined }) });
  if (!dsRes.ok) { console.error('deepseek', dsRes.status, await dsRes.text()); return heuristicAI(task, lead); }
  const dsData = await dsRes.json();
  const raw = dsData.choices?.[0]?.message?.content || '';
  let result;
  if (task === 'score') {
    try { const parsed = JSON.parse(raw); result = { score: Math.max(1, Math.min(10, Number(parsed.score) || 5)), reason: parsed.reason || '' }; }
    catch { const m = raw.match(/"score"\s*:\s*(\d+)/); result = { score: m ? Number(m[1]) : 5, reason: raw.slice(0, 120) }; }
    if (cacheKey) await env.CACHE?.put(cacheKey, JSON.stringify(result), { expirationTtl: AI_TTL });
  } else { result = { message: raw.trim() }; }
  return result;
}

function heuristicAI(task, lead) {
  if (task === 'score') {
    const issues = (lead?.checks || []).filter(c => !c[0]).length;
    return { score: Math.min(10, 5 + issues), reason: `${issues} problème(s) détecté(s) — score heuristique.` };
  }
  return { message: `Bonjour ${lead?.name || ''}\n\nJe suis de CNMFOX, agence web haïtienne. Je peux vous proposer un devis gratuit pour améliorer votre présence en ligne.\n\n— CNMFOX` };
}

async function rateLimit(env, ip) {
  if (!env.CACHE) return { ok: true };
  const key = `rl:${ip}:${Math.floor(Date.now() / 1000 / RATE_LIMIT_WINDOW)}`;
  const current = Number(await env.CACHE.get(key) || 0);
  if (current >= RATE_LIMIT_MAX) return { ok: false, resetIn: RATE_LIMIT_WINDOW - (Math.floor(Date.now() / 1000) % RATE_LIMIT_WINDOW) };
  await env.CACHE.put(key, String(current + 1), { expirationTtl: RATE_LIMIT_WINDOW });
  return { ok: true };
}

function json(obj, status = 200) { return new Response(JSON.stringify(obj), { status, headers: { 'Content-Type': 'application/json' } }); }

function cors(res, origin, env) {
  const allow = env?.ALLOWED_ORIGIN || '*';
  const h = new Headers(res.headers);
  h.set('Access-Control-Allow-Origin', allow === '*' ? '*' : (allow.split(',').includes(origin) ? origin : allow));
  h.set('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  h.set('Access-Control-Allow-Headers', 'Content-Type,X-CNMFOX-Token');
  h.set('Access-Control-Max-Age', '86400');
  return new Response(res.body, { status: res.status, headers: h });
}
