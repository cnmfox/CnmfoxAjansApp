# CNMFOX — APK Android SANS Android Studio (Capacitor + GitHub Actions)

Ce paquet contient un projet Capacitor complet qui construit l'APK **automatiquement dans le cloud** (GitHub Actions) à chaque `push`. Aucune installation locale de Node, Android Studio ni JDK n'est nécessaire.

---

## 1. Arborescence exacte des fichiers

```
cnmfox-apk/
├── package.json                        # Dépendances Capacitor (core/cli/android/splash-screen)
├── capacitor.config.json               # Config Capacitor extraite du KIT (appId com.cnmfox.app)
├── .gitignore                          # Exclut android/, node_modules, keystore, key.properties
├── README.md                           # Ce fichier
│
├── www/
│   └── index.html                      # L'app web embarquée. Pour l'instant : les maquettes
│                                       #   démo (votre choix). À remplacer par le vrai app.html.
│
├── .github/
│   └── workflows/
│       └── build-apk.yml               # Workflow : build APK debug (+ release signé si secrets)
│
└── worker/                             # Backend Cloudflare Worker (extraits du KIT, déploiement séparé)
    ├── wrangler.toml
    ├── src/
    │   └── index.js                    # Worker complet (search/scrape/ai + cache KV + rate limit)
    ├── key.properties.template         # Modèle de signature (provenance KIT)
    └── app.html-from-kit-BROKEN.txt    # L'app.html tronqué du KIT, conservé pour preuve (133 octets)
```

L'APK généré se trouve dans l'artefact `cnmfox-debug-apk` (fichier `app-debug.apk`).

---

## 2. Ce qui a été réparé dans le KIT (et pourquoi)

| Problème dans le KIT | Correction | Pourquoi |
|---|---|---|
| `app.html` **tronqué** : 133 octets, uniquement du texte visible, aucune balise `<html>/<script>/<style>` | Remplacé par `CNMFOX_Mockups_Demo(1).html` dans `www/index.html` (votre choix) | L'app.html du KIT ne pouvait pas s'exécuter. Voir §5 pour la remplacer par la vraie. |
| Exigeait **Android Studio + JDK 17 en local** | Build cloud via GitHub Actions | Objectif initial : ne pas installer Android Studio. |
| Conseillait de modifier `android/app/build.gradle` pour la signature | **Inutile** : Capacitor lit déjà `android/app/key.properties` nativement. Le CI génère ce fichier depuis les secrets. | Évite une modification manuelle fragile. |
| Mots de passe en dur de secours (`"VOTPAS"`) dans `build.gradle` | Supprimés — uniquement des secrets GitHub | Un mot de passe committé = faille de sécurité. |
| Pas de `.gitignore` | Ajouté (`android/`, `node_modules/`, `*.keystore`, `key.properties`) | Évite de committer 100 Mo de fichiers générés et des secrets. |
| `capacitor.config.json` référence `SplashScreen` mais le plugin n'était pas installé | `@capacitor/splash-screen` ajouté aux dépendances | Sinon la config de splash est ignorée. |

---

## 3. Prérequis (minimal)

- Un compte **GitHub** (gratuit) — https://github.com/join
- Soit `git` installé, soit la possibilité de glisser-déposer des fichiers sur le site web de GitHub.
- **Rien d'autre.**

---

## 4. Étapes : publier sur GitHub → télécharger l'APK

### Étape 1 — Créer un dépôt vide
Sur https://github.com/new :
- Nom : `cnmfox-app` (ou ce que vous voulez)
- **Ne pas** cocher « Add a README file », **ni** « Add .gitignore » (il faut un dépôt vide).
- Public ou Private (les deux fonctionnent avec GitHub Actions).

### Étape 2 — Envoyer les fichiers
**Option A (ligne de commande, recommandé) :** décompressez ce zip, ouvrez un terminal dans le dossier `cnmfox-apk/`, puis :
```bash
git init
git add .
git commit -m "CNMFOX: projet Capacitor + workflow APK"
git branch -M main
git remote add origin https://github.com/VOTRE-PSEUDO/cnmfox-app.git
git push -u origin main
```

**Option B (sans ligne de commande) :** sur la page web du dépôt vide, cliquez sur « uploading an existing file » et glissez-déposez **tout le contenu** du dossier `cnmfox-apk/` (y compris les dossiers cachés `.github/` et `.gitignore`). Validez avec « Commit changes ».

### Étape 3 — Lancer le build
Allez dans l'onglet **Actions** du dépôt. Le workflow *« Build CNMFOX APK »* se lance **automatiquement**. Comptez **5 à 10 minutes** (la première fois, Gradle télécharge les dépendances Android).

### Étape 4 — Télécharger l'APK
Quand le run devient vert (✅) :
1. Cliquez sur le run.
2. En bas de page, section **Artifacts** → cliquez sur `cnmfox-debug-apk` (un zip).
3. Décompressez-le : vous obtenez `app-debug.apk`.

### Étape 5 — Installer sur le téléphone
- Transférez `app-debug.apk` sur le téléphone (USB, Google Drive, email, WhatsApp…).
- Touchez le fichier → autorisez « **Installer depuis des sources inconnues** » (Paramètres → Sécurité).
- L'application « CNMFOX » apparaît dans le tiroir d'applications.

---

## 5. Remplacer par la vraie app HTML (plus tard)

Quand vous avez le vrai `app.html` complet :
1. Remplacez `www/index.html` par ce fichier (renommez-le `index.html`).
2. `git add . && git commit -m "App réelle" && git push`
3. Un nouvel APK se construit automatiquement → onglet Actions → Artifacts.

⚠️ **Important dans l'APK :** l'URL du backend (Worker Cloudflare) doit être en **`https://`** (pas `http://`), sinon Android bloque la requête (mixed content). C'est noté dans le KIT §9.

---

## 6. APK signé (release) — optionnel, pour le Play Store

L'APK debug (§4) suffit pour tester et distribuer en direct. Pour le **Play Store** (25 $ une fois), il faut un APK/AAB signé :

1. Générer un keystore (sur n'importe quelle machine avec Java — ex: Google Cloud Shell gratuit, ou un ordinateur ami) :
   ```bash
   keytool -genkey -v -keystore cnmfox-release.keystore -alias cnmfox \
     -keyalg RSA -keysize 2048 -validity 10000
   ```
   **Conservez précieusement ce fichier et ses mots de passe** (perte = impossible de mettre à jour l'app sur le Play Store).

2. Encoder le keystore en base64 :
   - Linux/Mac : `base64 -w0 cnmfox-release.keystore`
   - Windows : `certutil -encode cnmfox-release.keystore tmp.b64 && type tmp.b64`

3. Dans GitHub : **Settings → Secrets and variables → Actions → New repository secret**, ajouter 4 secrets :
   | Nom | Valeur |
   |---|---|
   | `KEYSTORE_BASE64` | La longue chaîne base64 (une seule ligne) |
   | `KEYSTORE_PASSWORD` | Le mot de passe du keystore |
   | `KEY_ALIAS` | `cnmfox` |
   | `KEY_PASSWORD` | Le mot de passe de la clé (souvent identique) |

4. Relancer le workflow (onglet Actions → *Run workflow*). En plus du debug, vous récupérez l'artefact `cnmfox-release-apk` → `app-release.apk`, signé et prêt pour le Play Console.

---

## 7. Backend (Worker Cloudflare) — dossier `worker/`

Le dossier `worker/` contient `wrangler.toml` et `src/index.js` **extraits et complets** du KIT. Ce backend est **indépendant** de l'APK : déployez-le séparément avec Wrangler (cf. KIT §6), puis collez son URL + token dans les paramètres de l'app.

- `worker/app.html-from-kit-BROKEN.txt` = l'app.html tronqué du KIT, conservé tel quel pour démontrer le défaut.
- `worker/key.properties.template` = modèle de signature du KIT (déjà intégré au workflow, conservé pour référence).

---

## 8. Dépannage rapide

- **Run rouge (échec)** : ouvrez le run, lisez les logs. Cause fréquente : branche qui ne s'appelle pas `main`/`master` (le workflow écoute ces deux noms — utilisez sinon le bouton *Run workflow* manuel).
- **Quota GitHub Actions** : comptes gratuits = 2000 min/mois (privé) ou illimité (public). Un build ≈ 6 min.
- **Écran blanc dans l'APK** : erreur JavaScript dans `index.html` — testez d'abord en ouvrant `www/index.html` dans Chrome (F12 → Console).
- **« App not installed »** : désinstallez une ancienne version du même `appId` avant de réinstaller.
- **Connexion backend échoue** : URL en `https://`, token identique à `CNMFOX_TOKEN` du Worker, CORS autorisé (`ALLOWED_ORIGIN = "*"` par défaut).
